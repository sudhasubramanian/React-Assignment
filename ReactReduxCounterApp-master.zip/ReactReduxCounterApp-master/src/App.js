import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect,
  useHistory,
  useLocation
} from "react-router-dom";

import Login from './Containers/login';
import Home from './Containers/home';


export default function App() {
  return (
    <Router>   
        <ScreenCheck />
        <Switch>        
          <RouteAuthWrapper path="/protected">
            <Home />
          </RouteAuthWrapper>
        </Switch>
     
    </Router>
  );
}

function ScreenCheck() {
  let history = useHistory();
  return ( checkAuthentication.isAuthenticated ?  <Home checkAuthentication={checkAuthentication} history={history} /> :
     <Login checkAuthentication={checkAuthentication}/> );  
}


function RouteAuthWrapper({ children, ...rest }) {
  return (
    <Route
      {...rest}
      render={({ location }) =>checkAuthentication.isAuthenticated ? ( children) :(<Redirect to={{pathname: "/login",state: { from: location } }} />)
      }
    />
  );
}

const checkAuthentication = {
  isAuthenticated: false,
  authenticate(cb) {
    checkAuthentication.isAuthenticated = true;
    setTimeout(cb, 100); 
  },
  signout(cb) {
    checkAuthentication.isAuthenticated = false;
    setTimeout(cb, 100);
  }
};