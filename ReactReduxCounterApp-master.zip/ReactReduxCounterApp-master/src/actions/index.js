export const incrementCountBy1 = count => {
  const num = count+1
  return {
  type: 'INCREMENT_COUNT1',
  count: num
  }
}

export const incrementCountBy2 = count => {
  const num = count+2
  return {
    type: 'INCREMENT_COUNT2',
    count: num
  }
}

export function submit() {
  return { type: "SUBMIT" };
}