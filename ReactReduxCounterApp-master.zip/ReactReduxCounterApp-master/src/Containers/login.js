// import React from 'react';  
// import 'bootstrap/dist/css/bootstrap.min.css'; 
// import Container from 'react-bootstrap/Container'
// import Row from 'react-bootstrap/Row'
// import Col from 'react-bootstrap/Col'

// class Login extends React.Component{

//     constructor(props){
//         super(props)
//         this.props =  props;
//         this.state = {username:'',password:''}
//         this.handleOnchange = this.handleOnchange.bind(this);
//         this.handleLogin = this.handleLogin.bind(this);
//         this.isLogged = false;
//     }

//     handleOnchange = (e) =>{

//       let name = e.target.name;
//       let val = e.target.value;
//       this.setState({[name]: val});

//      if(this.state.username && this.state.password)
//          this.isLogged = true;        
//     }

//     handleLogin = (e) =>{   
//         if(!(this.state.username && this.state.password))   
//                     alert('Please enter your credentials');
        
//         this.props.loginState(this.isLogged);
//     }

//     handleReset = (e) =>{      
//        document.getElementById('username').value = '';
//        document.getElementById('password').value = '';
//        this.setState({username:'',password:''});
//        this.isLogged = false;     
//        this.props.loginState(this.isLogged);
//     }

// 	render(){ 
//         const loginStyles = {			
//             topMargin: {
//                 marginTop:30				
//             },	
//             leftMargin: {
//                 marginLeft:20				
//             }	
//         };

// 		return ( 

//             <Container style={{backgroundColor: '	#D3D3D3', border: '1px solid black', marginTop:100, padding:50, borderRadius: 10}}>
// 				<Row>					
// 					<Col xs={4}/>

//                     <Col xs={4}>
//                         <Row>
//                             <Col xs={12}>
//                                 <h1 align='center' style={{marginBottom:30, fontSize: '25px'}}>Bank Name</h1>
//                             </Col>
//                         </Row>

//                         <Row>
//                             <Col xs={5}>
//                             <label htmlFor="username">Customer Id:</label><br/></Col>
//                             <Col xs={7}> <input type="text" name="username" style={{border: '1px solid black'}} id="username" className="form-control"onChange={this.handleOnchange}/>
//                             </Col>
//                         </Row>

//                         <Row style={{marginTop:20}}>
//                             <Col xs={5}>
//                             <label htmlFor="password">Password:</label><br/></Col>
//                             <Col xs={7}><input type="password" name="password" id="password" style={{border: '1px solid black'}} className="form-control" onChange={this.handleOnchange}/>
//                             </Col>
//                         </Row>

//                         <Row>
//                             <Col xs={12} style={loginStyles.topMargin}>
//                             <Row>
//                             <Col xs={8} >
//                             <button className="float-right"   onClick={this.handleLogin}>Login</button>  
//                             </Col>   
//                             <Col xs={4} >
//                             <button  style={loginStyles.leftMargin} className="float-right" onClick={this.handleReset}>Reset</button>                           
//                             </Col>                         
//                             </Row>
//                             </Col>
//                         </Row>
//                    </Col>

//                   <Col xs={4}/>   
					
// 			  </Row>

//             </Container>
// 		);
// 	}
// }

// export default Login;
import React,{useRef} from "react";
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import { Container, makeStyles } from '@material-ui/core';

import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link,
    Redirect,
    useHistory,
    useLocation
  } from "react-router-dom";


function Login(props) {

    const useStyles = makeStyles(theme => ({
        root: {         
          background:'#E2DFFE'          
        },
      }));
    
      const classes = useStyles();

    let history = useHistory();
    let location = useLocation();
   
    const [username, setUsername] = React.useState(false);   

    let { from } = location.state || { from: { pathname: "/" } };
  
    let handleLogin = () => {       
      props.checkAuthentication.authenticate(() => {
        history.replace(from);
      });
    };

    const handleReset = () =>{      
        document.getElementById('username').value = '';
        document.getElementById('password').value = '';       
     }
  

    return (
        
            <Grid container >

            <Grid item xs={4} ></Grid>
            <Grid item xs={4} >
           
                        <Grid container style={{backgroundColor: '	#D3D3D3', border: '1px solid black', marginTop:100, padding:50, borderRadius: 10}} >

                                <Grid container >
                                    <Grid item xs={12} > <h1>UOB Bank</h1>   </Grid>
                                </Grid>
                                <Grid container >
                                <Grid item xs={6} style={{marginTop:10	}}> Customer Id: </Grid>                                
                                    <Grid item xs={6} ><TextField id="username"  label="User Name" variant="outlined" /></Grid>
                                </Grid>
                                <Grid container style={{marginTop:10	}}>
                                <Grid item xs={6} style={{marginTop:10	}}> Password: </Grid> 
                                    <Grid item xs={6} ><TextField id="password" label="Password" type='password' variant="outlined"/></Grid>
                                </Grid>
                                <Grid container style={{marginTop:30}}>
                                    <Grid item xs={6} ><Button variant="contained" size="small" color="primary"  onClick={handleLogin}> Login</Button></Grid>
                                    <Grid item xs={6} > <Button variant="contained" size="small" color="secondary" onClick={handleReset}>Reset</Button></Grid>
                                </Grid>

                            </Grid>
                           
                        </Grid>                 
              <Grid item xs={4}></Grid>            
            </Grid>
)
  }

  export default Login