import React from "react";
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { Container, makeStyles } from '@material-ui/core';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Collapse from '@material-ui/core/Collapse';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import { Link } from '@material-ui/core';

function Home(props) {
    const useStyles = makeStyles(theme => ({
        root: {
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background:'#E2DFFE',
          
        },
      }));
    
      const classes = useStyles();

    
  const [expand1, setExpandable1] = React.useState(true);
  const [expand2, setExpandable2] = React.useState(true);

  const handleClick = () => {
    setExpandable1(!expand1);
  };

  const handleClick2 = () => {
    setExpandable2(!expand2);
  };


    return  (
        <Container maxWidth={false} className={classes.root}>
              <Grid container spacing={3}  style={{backgroundColor: '	#FFFFFF'}}  >        
                 <Grid item xs={12} >
                 <AppBar position='static' style={{backgroundColor: '	#D3D3D3'}}>
                   <Toolbar>  
                        <Grid container spacing={3} > 
                        <Grid item xs={10} ><Typography variant="h8" className={classes.title}>Welcome to ABC Bank</Typography></Grid>
                        <Grid item xs={1} ><AccountCircleIcon/></Grid>
                        <Grid item xs={1} > 
                                <Button variant="contained" size="small" color="secondary"  onClick={() => { props.checkAuthentication.signout(() => props.history.push("/"));}}>
                                    Logout
                                </Button>  
                            </Grid>
                        </Grid>                                       
                     </Toolbar>      
                   </AppBar>
                 </Grid>     
                 <Grid item xs={12}>   
                    <Grid container spacing={2}>                    
                    <Grid item xs={3} style={{backgroundColor: '	#D3D3D3', border: '1px solid black',  borderRadius: 10}}>                     
                    <Typography variant="h8" className={classes.title}>Account Summary</Typography> 
                    <List>
                        <ListItem button onClick={handleClick}>       
                            <ListItemText primary="Savings" />
                            {expand1 ? <ExpandLess /> : <ExpandMore />}
                        </ListItem>
                        <Collapse in={expand1} timeout="auto" unmountOnExit>
                            <List >
                            <ListItem >                            
                                <ListItemText primary="Open FD" />
                            </ListItem>
                            <ListItem >                            
                                <ListItemText primary="Open RD" />
                            </ListItem>
                            <ListItem >                            
                                <ListItemText primary="View Deposits" />
                            </ListItem>
                            </List>
                        </Collapse>
                        </List>
                    <List>
                        <ListItem button onClick={handleClick2}>       
                            <ListItemText primary="Funds Transfer" />
                            {expand2 ? <ExpandLess /> : <ExpandMore />}
                        </ListItem>
                        <Collapse in={expand2} timeout="auto" >
                            <List >
                            <ListItem >
                            
                                <ListItemText primary="View Payee" />
                            </ListItem>
                            <ListItem >
                            
                                <ListItemText primary="Transfer" />
                            </ListItem>
                            </List>
                        </Collapse>
                        </List>
                    </Grid>
                     <Grid item xs={9} > 
                       <Typography variant="h8">Saving Accounts</Typography>
                       <Box border={1} p={2} m={2} style={{backgroundColor: '	#D3D3D3', border: '1px solid black',  borderRadius: 10}}> 
                          <Grid container spacing={2}   >
                            <Grid item xs={4}> <Typography variant="h8" >Account Number</Typography></Grid>  
                            <Grid item xs={4}> <Typography variant="h8" >Branch</Typography></Grid>  
                            <Grid item xs={4}> <Typography variant="h8" >Amount</Typography></Grid>  
                           </Grid>
                           <Grid container spacing={2}>
                            <Grid item xs={4}> <Typography variant="h8" >100000001</Typography></Grid>  
                            <Grid item xs={4}> <Typography variant="h8" >Chennai</Typography></Grid>  
                            <Grid item xs={4}> <Typography variant="h8" >50000</Typography></Grid>  
                           </Grid>
                        </Box> 
                       <Typography variant="h8" m={2}>Deposits</Typography>
                       <Box border={1} p={2} m={2}  style={{backgroundColor: '	#D3D3D3', border: '1px solid black',  borderRadius: 10}}> 
                          <Grid container spacing={2}  >
                            <Grid item xs={4}> <Typography variant="h8" >Fixed Deposits</Typography></Grid>  
                            <Grid item xs={4}> <Typography variant="h8" >Recurrig Deposits</Typography></Grid>  
                            <Grid item xs={4}> <Typography variant="h8" ></Typography></Grid>  
                           </Grid>
                           <Grid container spacing={2} >
                            <Grid item xs={4}> <Typography variant="h8" >1000000</Typography></Grid>  
                            <Grid item xs={4}> <Typography variant="h8" >500000</Typography></Grid>  
                            <Grid item xs={4}> <Link href="#"> View All Deposits</Link></Grid>  
                           </Grid>
                        </Box> 
                     </Grid>
                    </Grid> 
                 </Grid>           
            </Grid>
        </Container>
    )

  }

  export default Home