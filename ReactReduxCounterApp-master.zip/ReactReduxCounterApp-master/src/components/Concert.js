//concert.js
import React from 'react';
// import './concert.css';
// import concerts from '../concerts'

var axios = require('axios');

 class Concert extends React.Component {

    getInitialState() {
    return {
        concerts: []
    }
}

    componentDidMount() {
    var th = this;
    this.serverRequest =
        axios.get('./concerts.json')
            .then(function(result) {
                th.setState({
                    concert: result.data
                   
                });
                alert(JSON.stringify(result.data));
            })
            alert(this.state.concert);
}


    componentWillUnmount() {
    this.serverRequest.abort();
}

    render(){
        return (
            <div>
                <h1>Concerts!</h1>                
                
            </div>
        )

    }

}
export default Concert;