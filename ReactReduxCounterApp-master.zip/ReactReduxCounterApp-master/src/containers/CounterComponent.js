import React, {Component} from 'react'
import Button from '../components/Button'
import {connect} from 'react-redux'
import {incrementCountBy1, incrementCountBy2, submit} from '../actions/index'

class CounterComponent extends Component{

handleBtnActionIncrementBy1= () => {
  this.props.onIncrementClickBy1(this.props.count)
}

handleBtnActionIncrementBy2 = () => {
  this.props.onIncrementClickBy2(this.props.count)
}

handleBtnActionSubmit = () => {
  this.props.onSubmit(this.props.submit)
}


render() {
  const {count}=this.props
  return(
    <div>
      <h1>Count: {count}</h1>
      <Button action={this.handleBtnActionIncrementBy1} buttonTitle = "+" />
      <Button action={this.handleBtnActionIncrementBy2} buttonTitle = "-" />
      <Button action={this.handleBtnActionSubmit} buttonTitle = "submit" />
    </div>
  )
}
}


const mapStateToProps = (state) => {
  return {
    count: state.counter.count
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    onIncrementClickBy1: (count) => {  
      dispatch(incrementCountBy1(count))
    },
    onIncrementClickBy2: (count) => {
      if(count !== 0) 
      dispatch(incrementCountBy2(count))
    }, 
    submit: () => dispatch(submit())
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(CounterComponent)