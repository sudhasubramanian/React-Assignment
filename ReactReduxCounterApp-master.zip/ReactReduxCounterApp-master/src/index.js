// import React from 'react'
// import ReactDOM from 'react-dom';
// import { render } from 'react-dom'
// import { Provider } from 'react-redux'
// import CounterComponent from './containers/CounterComponent'
// import store from './store'
// import Concert from './components/Concert'
// // import concert from './concert'



// // ReactDOM.render(<NavBar />, document.getElementById('navbar'));


// render(
//   <Provider store={store}>
//     <CounterComponent />
//   </Provider>,
   
//   document.getElementById('root')
// )
// // ReactDOM.render(<Concert source={process.env.PUBLIC_URL + '/concert.json'}/>, document.getElementById('concert'));
// // ReactDOM.render(<Concert source="./concert.json" />, document.getElementById(''));
// // ReactDOM.render(<Concert source={jsonResponse} />, document.getElementById('concert'));
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
  